---
name: code-indexer
description: "Семантическая навигация по коду с tree-sitter. Use when: (1) поиск определений/ссылок символов, (2) построение графа вызовов, (3) fuzzy поиск с опечатками, (4) анализ зависимостей перед рефакторингом. Triggers: найти определение, список функций, поиск символа, граф вызовов, call graph, where is defined, find symbol, кто вызывает, что вызывает."
---

# Code Indexer

Семантическая навигация по коду (50-77x быстрее grep для поиска символов).

## Decision Tree

```
Нужно найти что-то в коде?
├── Символ (функция, тип, класс)?
│   ├── Знаю точное имя → code-indexer definition <NAME>
│   ├── Знаю часть имени → code-indexer symbols <QUERY>
│   └── Могу ошибиться в написании → code-indexer symbols <QUERY> --fuzzy
├── Кто вызывает функцию? → code-indexer call-graph <FUNC> --direction in
├── Что вызывает функция? → code-indexer call-graph <FUNC> --direction out
├── Структура файла? → code-indexer outline <FILE>
├── Что изменилось в ветке? → code-indexer changed --base main
├── Текст/строка/комментарий → rg (НЕ code-indexer!)
└── Символ в зависимостях? → code-indexer deps find <SYMBOL>
```

## Trade-offs (экспертные знания)

### call-graph vs references --callers
- `references --callers` — плоский список: "функция X вызывает Y"
- `call-graph` — полный граф с глубиной: "A→B→C→D"
- **Правило**: для 1 уровня — `references --callers`, для ≥2 уровней — `call-graph --depth N`

### fuzzy-threshold
- `0.8` (default) — находит typos и case variations, минимум шума
- `0.6-0.7` — больше вариантов, полезно для "ищу что-то похожее на..."
- `<0.6` — слишком много шума, бесполезно

### certain vs possible confidence
В call-graph результаты имеют confidence:
- `certain` — прямой вызов, можно доверять
- `possible` — heuristic (dynamic dispatch, closures), проверь вручную

### --deep-deps
- БЕЗ флага: индексирует только ваш код
- С флагом: + типы из зависимостей (Cargo deps, node_modules)
- **Trade-off**: индекс растёт в 10-50x, индексация минуты вместо секунд
- **Когда нужен**: рефакторинг API, понимание как ваш код использует библиотеку

## NEVER

- **NEVER** используй code-indexer для строковых литералов/комментариев — tree-sitter не индексирует содержимое строк, получишь пустой результат → используй `rg`
- **NEVER** используй `--deep-deps` для быстрых сессий — индексация зависимостей занимает минуты
- **NEVER** доверяй `possible` confidence для критичных решений без ручной проверки
- **NEVER** забывай про `.code-index.db` — добавь в `.gitignore`
- **NEVER** запускай без индекса — сначала `code-indexer index`, потом запросы

## Patterns

### Ориентация в незнакомом коде
```bash
# 1. Индексация
code-indexer index

# 2. Точки входа
code-indexer symbols "main" --kind function
code-indexer symbols "handler" --kind function

# 3. Структура ключевого файла
code-indexer outline src/main.rs
```

### Подготовка к рефакторингу
```bash
# Кто использует функцию которую хочу изменить?
code-indexer call-graph "oldFunction" --direction in --depth 3

# Какие типы затронуты?
code-indexer references "OldType" --callers
```

### Fuzzy поиск при опечатке
```bash
# Не помню точное имя
code-indexer symbols "Cofnig" --fuzzy
# → Config, ConfigService, ConfigManager

# С контролем порога
code-indexer symbols "Hnadler" --fuzzy --fuzzy-threshold 0.7
```

### Анализ изменений для code review
```bash
# Что изменилось относительно main?
code-indexer changed --base main

# Кто вызывает изменённые функции? (blast radius)
code-indexer call-graph "changedFunc" --direction in
```

## Quick Reference

```bash
# Индексация
code-indexer index [PATH]           # Базовая
code-indexer index --watch          # Авто-обновление
code-indexer index --deep-deps      # С зависимостями

# Поиск
code-indexer symbols <Q> [--fuzzy]  # Поиск символов
code-indexer definition <NAME>       # Определение
code-indexer references <NAME>       # Ссылки

# Анализ
code-indexer call-graph <F> --direction in|out|both
code-indexer outline <FILE>
code-indexer changed [--base BRANCH]

# Зависимости
code-indexer deps find <SYMBOL>
```

## Поддерживаемые языки

rust, java, kotlin, typescript, javascript, python, go, csharp, cpp, swift, haskell, elixir, lua, bash, sql, yaml, toml, hcl (17)
